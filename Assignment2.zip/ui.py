# ui.py

# Starter code for assignment 2 in ICS 32 Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Eliya Khajeie
# ekhajeie@uci.edu
# 85362437
import re
from Profile import Profile,Post

def user_options_help():
    print("L - Lists the contents of the user specified directory.")
    print("C - Creates a new file in the specified directory.")
    print("D - Delete the file")
    print("R - Reads the contents of a file")
    print("O - Opens an existing file of the type dsu")
    print("E - Edit the DSU file loaded by C or O commands")
    print("P - Prints data stored in the DSU file loaded by C or O commands")
    print("Q - Exit the whole program")

def user_options():
    print("Welcome again! Would you like to create or load a DSU file (type 'C' to create or 'O' to load)")
    user_inp_ui = input()
    if user_inp_ui == "C" or user_inp_ui == "C ":
        print("Great! Now input 'C' followed by the proper commands to create a DSU file ")
    if user_inp_ui == "O" or user_inp_ui == "O ":
        print("Great! Now input 'O' followed by the proper commands to load a DSU file ")
    if user_inp_ui == "Q" or user_inp_ui == "Q ":
        quit()
    if user_inp_ui == "admin":
        print("Welcome admin, here are your options!")
        user_options_help()
        

def user_error():
    print("You have raised an error, is there anything else from the options list you would like to do? ")

def user_optE(full_path): #FULLY WORKS
    options = input("What option would you like to do? \n")
    if not options:
        print("Error: You didn't input any correct options")
    userE = Profile()
    userE.load_profile(full_path)

    usr_re = re.compile(r'-usr ([\w-]+)')
    pwd_re = re.compile(r'-pwd ([\w-]+)')
    bio_re = re.compile(r'-bio\s+["\']?((?:[^"\']|["\']{2})*)["\']?')  
    add_post_re = re.compile(r'-addposts\s+["\']?((?:[^"\']|["\']{2})*)["\']?')   
    del_post_re = re.compile(r"-delpost\s*(\d*)")
    option_strings = re.findall(r'-\w+ .*?(?=-\w+|$)', options)

    for opt_str in option_strings:
        usr_match = re.search(usr_re, opt_str)
        username = usr_match.group(1) if usr_match else None
        pwd_match = re.search(pwd_re, opt_str)
        password = pwd_match.group(1) if pwd_match else None
        bio_match = re.search(bio_re, opt_str)
        bio = bio_match.group(1) if bio_match else None
        add_post_match = re.search(add_post_re, opt_str)
        add_post = add_post_match.group(1) if add_post_match else None
        delpost_match = re.search(del_post_re, opt_str)
        del_post = int(delpost_match.group(1)) if delpost_match and delpost_match.group(1) else None
        if username:
            userE.username = username
            userE.save_profile(full_path)
        
        if password:
            userE.password = password
            userE.save_profile(full_path)

        if bio:
            userE.bio = bio
            userE.save_profile(full_path)

        if add_post:
            PostE = Post(add_post)
            userE.add_post(PostE)
            userE.save_profile(full_path)

        if del_post is not None:
            print(del_post)
            userE.del_post(int(del_post))
            userE.save_profile(full_path)
    inp_new = input("Would you like to do another E or P function?: E/P\n")
    if inp_new == "E":
        user_optE(full_path)
    if inp_new == "P":
        user_optP(full_path)
    if inp_new == "Q":
        quit()
    if inp_new != "P" and inp_new != "E":
        print("You inputted a wrong command you will be taken back to the start!")



def user_optP(user_path):
    options = input("What option would you like to do? \n")
    if not options:
        print("Error: You didn't input any correct options")
    userP = Profile()
    userP.load_profile(user_path)
    if "-usr" in options: #works 
        print("Username:", userP.username)
    if "-pwd" in options: #works 
        print("Password:", userP.password)
    if "-bio" in options: #works 
        if len(userP.bio) > 0:
            print("Bio:", userP.bio)
        else:
            print("Your bio is empty if you would like to add one use the E function")

    if "-posts" in options:
        count_posts = 0
        print("Posts:")
        for i in userP.get_posts():
            print(f'{count_posts}: {i["entry"]}')
            count_posts += 1
    if "-post " in options:
        us_opt = re.compile(r'-post \d+')
        us_num = us_opt.search(options).group()[6:]
        us_num = int(us_num)
        us_list = userP.get_posts()
        print(us_list[us_num])
    if "-all" in options:
        print("Username:", userP.username)
        print("Password:", userP.password)
        if len(userP.bio) > 0:
            print("Bio:", userP.bio)
        else:
            print("Your bio is empty if you would like to add one use the E function")
        count_posts = 0
        print("Posts:")
        for i in userP.get_posts():
            print(f'{count_posts}: {i["entry"]}')
            count_posts += 1




    inp_new = input("Would you like to do another E or P function?: E/P\n")
    if inp_new == "E":
        user_optE(user_path)
    if inp_new == "P":
        user_optP(user_path)
    if inp_new == "Q":
        quit()
    if inp_new != "P" and inp_new != "E":
        print("You inputted a wrong command you will be taken back to the start!")